# LX9quad
LX9quad： the Nine-Quadrantal Diagram of transcriptome and metabolome
